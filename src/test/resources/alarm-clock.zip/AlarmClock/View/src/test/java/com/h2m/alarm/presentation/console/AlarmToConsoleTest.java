package com.h2m.alarm.presentation.console;

import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class AlarmToConsoleTest
{
    @Test
    public void dummyTest()
    {
        assertTrue(true);
    }
}